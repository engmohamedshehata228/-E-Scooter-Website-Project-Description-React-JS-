import Card from "./Card";
import Footer from "../Home/Footer"
function ProductsScrollContent()
{
    return(
        <div class="scrollable-content">
            <div class="products-grid fade-in-up">
                <Card New={"new"} badge={"New"} name={"Urban Lite"} km1={"40 KM"} km2={"13 KM"} price={1000}  src="Scooter.avif" />
                <Card New={""} badge={"Best Saller"} name={"Sport Glide S"} km1={"20 KM"} km2={"14 KM"} price={2500}  src="Scooter1.jpg" />
                <Card New={"new"} badge={"new"} name={"Urban Lite"} km1={"10 KM"} km2={"13 KM"} price={3000}  src="Scooter2.webp" />
                <Card New={""} badge={"Best Saller"} name={"Raptor Off-Road"} km1={"15 KM"} km2={"10 KM"} price={2000}  src="Scooter3.webp" />
                <Card New={""} badge={""} name={"Sport Glide S"} km1={"20 KM"} km2={"15 KM"} price={100}  src="Scooter5.jpg" />
                <Card New={"new"} badge={"New"} name={"Urban Lite"} km1={"40 KM"} km2={"30 KM"} price={450}  src="Scooter4.jpg" />
                <Card New={""} badge={""} name={"Raptor Off-Road"} km1={"13 KM"} km2={"3 KM"} price={500}  src="Scooter1.jpg" />
                <Card New={""} badge={""} name={"Urban Lite"} km1={"3 KM"} km2={"1 KM"} price={350}  src="Scooter5.jpg" />
                <Card New={""} badge={""} name={"Raptor Off-Road"} km1={"100 KM"} km2={"50 KM"} price={4000}  src="Scooter3.webp" />
                <Card New={""} badge={""} name={"Sport Glide S"} km1={"60 KM"} km2={"15 KM"} price={780}  src="Scooter4.jpg" />
                <Card New={"new"} badge={"New"} name={"Urban Lite"} km1={"30 KM"} km2={"14 KM"} price={980}  src="Scooter2.webp" />
            </div>
             <Footer/>
        </div>
    );

}

export default ProductsScrollContent