import LeftSection from "../Home/LeftSection";
import ProductsRightSection from "./ProductsRightSection";
function Products()
{
   return(
    <>
    <LeftSection pic='boy.jpg' className1="fa-solid fa-arrow-left" c2={"left_in_any_padge"}/>
    <ProductsRightSection/>
    </>
   );
}


export default Products