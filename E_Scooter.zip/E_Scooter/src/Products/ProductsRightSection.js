import NavBar from "../Home/NavBar";
import Decoration from "../Home/Decoration";
import ProductsScrollContent from "./ProductsScrollableContent";
function ProductsRightSection()
{

    return(
        <>
        <div class="right-section product-layout">
            <NavBar/>
                <div className="filter-bar fade-in-down">
                <span className="active">All Models</span>
                <span>Urban</span>
                <span>Off-Road</span>
                <span>Kids</span>
            </div>
            <ProductsScrollContent/>
            <Decoration/>
        </div>
        </>
    );

}

export default ProductsRightSection