

function Card({New , src="" , name , km1 ,km2 , price , badge=""})
{
    return(
        <div className="product-card">
             <div className={"badge " + New} >{badge}</div>
            <div className="p-image">
            <img src={src} alt="City Pro"/>
            </div>
        <div className="p-details">
            <h3>{name}</h3>
            <div className="specs">
                <span><i className="fa-solid fa-bolt"></i>{km1}</span>
                <span><i className="fa-solid fa-battery-full"></i> {km2}</span>
            </div>
            <div className="price-row">
                <span className="price">$ {price}</span>
                <button className="btn-add"><i className="fa-solid fa-cart-plus"></i></button>
            </div>
        </div>
    </div>
    );
}

export default Card