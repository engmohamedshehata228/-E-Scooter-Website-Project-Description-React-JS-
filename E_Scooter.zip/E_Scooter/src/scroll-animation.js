import { useEffect } from "react";
import { useLocation } from "react-router-dom";

export default function useScrollAnimations() {
  useEffect(() => {

    function isInViewport(element) {
      const rect = element.getBoundingClientRect();
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      return rect.top <= windowHeight - 100 && rect.bottom >= 0;
    }

    function handleScrollAnimations() {
      const animatedElements = document.querySelectorAll(
        '.scroll-animate, .fade-in-up, .fade-in-down, .fade-in-left, .fade-in-right, ' +
        '.zoom-in, .slide-in-left, .slide-in-right, .bounce-in, .rotate-in'
      );

      animatedElements.forEach((element) => {
        if (isInViewport(element) && !element.classList.contains('animate')) {
          setTimeout(() => {
            element.classList.add('animate');
          }, 100);
        }
      });
    }

    let scrollTimeout;
    function throttledScroll() {
      if (!scrollTimeout) {
        scrollTimeout = setTimeout(() => {
          handleScrollAnimations();
          scrollTimeout = null;
        }, 16);
      }
    }

    handleScrollAnimations();

    window.addEventListener('scroll', throttledScroll);
    window.addEventListener('resize', handleScrollAnimations);

    if ('IntersectionObserver' in window) {
      const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      };

      const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              entry.target.classList.add('animate');
            }, 100);
          }
        });
      }, observerOptions);

      const animatedEls = document.querySelectorAll(
        '.scroll-animate, .fade-in-up, .fade-in-down, .fade-in-left, .fade-in-right, ' +
        '.zoom-in, .slide-in-left, .slide-in-right, .bounce-in, .rotate-in'
      );

      animatedEls.forEach((element) => observer.observe(element));
    }

    return () => {
      window.removeEventListener('scroll', throttledScroll);
      window.removeEventListener('resize', handleScrollAnimations);
    };

  }, [useLocation().pathname]);
}
