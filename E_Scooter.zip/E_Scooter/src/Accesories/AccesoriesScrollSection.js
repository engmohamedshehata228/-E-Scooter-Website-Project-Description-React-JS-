import Card from "../Products/Card";
import Footer from "../Home/Footer"
function AccesoriesScrollSection()
{
  return(
        <>
 <div class="scrollable-content">
    <div class="products-grid fade-in-up">
        <Card price={200}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter4.jpg"  />
        <Card price={220}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter3.webp"  />
        <Card price={240}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Phone _Holder.jpg"  />
        <Card price={200}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="lock.jpg"  />
        <Card price={500}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet1.webp"  />
        <Card price={100}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter4.jpg"  />
        <Card price={400}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Phone _Holder.jpg"  />
        <Card price={800}  name={"Heavy Duty Lock"}  New={"new"}  badge="New" km1={"hello"}  src="lock.jpg"  />
        <Card price={900}  name={"Phone Mount"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet2.webp"  />
        <Card price={800}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Phone _Holder.jpg"  />

        <div className="promo-banner fade-in-up">
                <div className="promo-text">
                    <h4 className="zoom-in">Safety Bundle</h4>
                    <p className="fade-in-left stagger-1">Helmet + Knee Pads</p>
                    <span className="bounce-in stagger-2">-20% OFF</span>
                </div>
                <i className="fa-solid fa-shield-cat promo-icon rotate-in stagger-3"></i>
        </div>
        <Card price={100}  name={"Heavy Duty Lock"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter3.webp"  />
        <Card price={200}  name={"Phone Mount"}  New={"new"}  badge="New" km1={"hello"}  src="Phone _Holder.jpg"  />
        <Card price={300}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet1.webp"  />
        <Card price={500}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter3.webp"  />
        <Card price={800}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet1.webp"  />
        <Card price={900}  name={"Heavy Duty Lock"}  New={"new"}  badge="New" km1={"hello"}  src="lock.jpg"  />
        <Card price={600}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter4.jpg"  />
        <Card price={300}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="Scooter3.webp"  />
        <Card price={700}  name={"Phone Mount"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet1.webp"  />
        <Card price={400}  name={"Riding Gloves"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet2.webp"  />
        <Card price={100}  name={"Smart Helmet"}  New={"new"}  badge="New" km1={"hello"}  src="Smart _Helmet2.webp"  />
        <div className="divide"></div>
    </div>
     <Footer/>
</div>

        </>
  );
}




export default AccesoriesScrollSection