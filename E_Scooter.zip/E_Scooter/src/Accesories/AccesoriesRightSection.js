import NavBar from "../Home/NavBar"
import Decoration from "../Home/Decoration";
import AccesoriesScrollSection from "./AccesoriesScrollSection";

function AccesoriesRightSection()
{
    return(
      <div class="right-section product-layout">
        <NavBar/>
            <div className="page-intro fade-in-up">
                <h2 className="zoom-in acc" >Upgrade <span>Your Ride</span></h2>
                <p className="fade-in-left stagger-1">Essentials for safety and comfort.</p>
            </div>
            <AccesoriesScrollSection/>
            <Decoration/>
        </div>
    )
}


export default AccesoriesRightSection