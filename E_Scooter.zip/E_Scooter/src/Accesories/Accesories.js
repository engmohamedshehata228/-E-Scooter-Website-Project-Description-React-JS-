import LeftSection from "../Home/LeftSection";
import AccesoriesRightSection from "./AccesoriesRightSection";

function Accesories()
{
    return(
        <>
        <LeftSection pic="Motorcycle.avif" className1="fa-solid fa-arrow-left" c2={"left_in_any_padge"}/>
        <AccesoriesRightSection/>
        </>
    );
}


export default Accesories