import { useEffect } from 'react';
import Home from './Home/Home';
import About from './About/About';
import Products from "./Products/Products";
import Accesories from "./Accesories/Accesories";
import Contact from "./Conact/Conact";
import useScrollAnimations from "./scroll-animation";
import './Home/Home.css';
import './About/About.css';
import './Products/Products.css';
import './Accesories/Accesories.css';
import './Conact/Conact.css';

import { Route , Routes , useLocation} from 'react-router-dom';
function App() {
   useScrollAnimations();
   const location=useLocation()
   useEffect(()=>{
      if(location.pathname==='/')
      {
           document.getElementById("root").style="overflow: visible;"
      }
      else
      {
           document.getElementById("root").style="overflow: hidden;"
      }
   },[location.pathname])
  return (
     <>
          {/* Routes */}
          <Routes>
             <Route path='/' element={<Home/>}/>
             <Route path='/about'element={<About/>} />
             <Route path="/Products" element={<Products/>} />
             <Route path="/ACCESORIES" element={<Accesories/>}  />
             <Route path="/CONTACT"  element={<Contact/>} />
          </Routes>
     </>
  );
}
export default App;
