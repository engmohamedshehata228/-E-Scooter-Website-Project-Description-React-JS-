import NavBar from "../Home/NavBar";
import Decoration from "../Home/Decoration"
import ContactScrollSection from "./ContentScrollSection";
function ContactRightSection()
{
    return(

        <div class="right-section product-layout">
            <NavBar/>
            <ContactScrollSection/>
            <Decoration/>
        </div>
    );
}

export default ContactRightSection