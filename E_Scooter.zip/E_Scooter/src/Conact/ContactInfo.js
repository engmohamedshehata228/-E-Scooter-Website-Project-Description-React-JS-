import CardInfo from "./CardInfo";
function ContactInfo()
{
    return(
        <div class="contact-info-row fade-in-up">
            <CardInfo name={"Facebook"} num={"1"} info={"Mohamed Mahmoud Shehata"} Icon="Facebook"/>
            <CardInfo name={"Twitter"} num={"2"} info={"Mohmaed Mahmoud Shehata"} Icon="Twitter"/>
            <CardInfo name={"Inestagram"} num={"3"} info={"Mohamed Mahmoud"} Icon="Inestagram"/>
            <CardInfo name={"Location"} num={"4"} info={"El_Arish Egypt"} Icon="Location" dot="-dot"/>
            <CardInfo name={"Phone"} num={"5"} info={"01284309532"} Icon="Phone"/>
        </div>
    );
}

export default ContactInfo