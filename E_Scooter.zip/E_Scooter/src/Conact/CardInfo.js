
function CardInfo({Icon="" , num , name , info , dot=""})
{

    return(
        <div className={"c-info-box bounce-in stagger-"+num}>
            <div className="icon-circle">
                <i className={"fa-solid fa-" +Icon+dot}></i>
            </div>
            <h5>{name}</h5>
            <span>{info}</span>
        </div>
    );

}
export default CardInfo