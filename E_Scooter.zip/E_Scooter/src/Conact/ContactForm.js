function ContactForm()
{
    return(
        <div className="contact-form-wrapper fade-in-up">
            <h3 className="zoom-in">Send a Message</h3>
            <form action="#">
                <div className="input-group fade-in-left stagger-1">
                    <input type="text" placeholder="Your Name" required />
                    <input type="email" placeholder="Your Email" required />
                </div>
                <input type="text" placeholder="Subject" class="full-width fade-in-right stagger-2" required/>
                <textarea placeholder="Write your message here..." rows="4" class="fade-in-left stagger-3"></textarea>
                <button type="submit" className="btn-send bounce-in stagger-4">
                    SEND MESSAGE <i className="fa-solid fa-paper-plane"></i>
                </button>
            </form>
        </div>
    );
}

export default ContactForm