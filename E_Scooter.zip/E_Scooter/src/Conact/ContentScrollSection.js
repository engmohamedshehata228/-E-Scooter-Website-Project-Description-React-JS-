import ContactForm from "./ContactForm";
import ContactInfo from "./ContactInfo";

function ContactScrollSection()
{
  return(
    <div class="scrollable-content">
        <div className="contact-intro fade-in-up">
            <h2 className="zoom-in">Get In <span>Touch</span></h2>
            <p className="fade-in-left stagger-1">Have questions about our scooters? We're here to help.</p>
        </div>
        <ContactInfo/>
        <ContactForm/>
        <div className="Dividor"></div>
    </div>
  );
}

export default ContactScrollSection