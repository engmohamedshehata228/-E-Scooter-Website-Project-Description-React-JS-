import LeftSection from "../Home/LeftSection";
import ContactRightSection from "./ContactRightSection";
import Footer from "../Home/Footer"
function Contact()
{
    return(
        <>
        <LeftSection pic="Labtop.avif" className1="fa-solid fa-arrow-left" c2={"left_in_any_padge"} />
        <ContactRightSection/>
        <Footer/>
        </>
    );
}


export default Contact