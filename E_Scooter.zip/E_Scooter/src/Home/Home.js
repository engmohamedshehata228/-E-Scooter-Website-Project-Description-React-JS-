
import LeftSection from './LeftSection'
import RightSection from './RightSection'
function Home()
{
  return(
 <>

              <LeftSection pic='girl.png' className1="fa-solid fa-magnifying-glass" className2="fa-regular fa-heart"/>
              <RightSection/>


 </>
  );
}


export default Home ;