
function Decoration()
{
  return(
             <div className="decoration">
                <div className="line line-1"></div>
                <div className="line line-2"></div>
                <div className="dots-box"></div>
                <div className="red-square"></div>
                <div className="hollow-square"></div>
            </div>
  )
}

export default Decoration