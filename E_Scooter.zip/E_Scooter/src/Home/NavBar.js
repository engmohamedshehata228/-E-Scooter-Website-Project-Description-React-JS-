import { NavLink } from "react-router-dom"
function NavBar({classNamehome="" , classNameabout="" , classNameproducts="" , classNameacce="" ,classNamecontact="" })
{
    return(
            <header className="fade-in-down">
                <div className="logo fade-in-left">
                    <i className="fa-solid fa-scooter"></i>
                    <span>e-scooter</span>
                </div>
                <nav class="fade-in-right">
                    <ul>
                        <li><NavLink to="/" >HOME</NavLink></li>
                        <li><NavLink to="/about">ABOUT</NavLink></li>
                        <li><NavLink to="/Products">PRODUCTS</NavLink></li>
                        <li><NavLink to="/ACCESORIES">ACCESORIES</NavLink></li>
                        <li><NavLink to="/CONTACT">CONTACT</NavLink></li>
                    </ul>
                </nav>
            </header>
    )
}

export default NavBar