
function LeftSection ({pic='/' , className1="" , className2="" , c2})
{
   return(
       <div className={"left-section "+c2}>
            <div className="top-icons">
                <i className={className1}></i>
                <i className={className2}></i>
            </div>
            <img src={pic} alt='' className="slide-in-left"/>
        </div>
   )
}


export default LeftSection;