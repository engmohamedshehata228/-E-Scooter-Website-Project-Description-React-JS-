
function Footer()
{

  return(
                <div class="footer-info fade-in-up stagger-3">
                <div class="social-icons">
                    <a  href="instagram" className="fade-in-left stagger-1"><i className="fa-brands fa-instagram"></i></a>
                    <a  href="facebook" className="fade-in-left stagger-2"><i className="fa-brands fa-facebook-f"></i></a>
                    <a  href="twitter" className="fade-in-left stagger-3"><i className="fa-brands fa-twitter"></i></a>
                    <a  href="whatsapp" className="fade-in-left stagger-4"><i className="fa-brands fa-whatsapp"></i></a>
                </div>
                <a href="website" class="website-link fade-in-up stagger-5">www.e-scooter.com</a>
            </div>
  );
}

export default Footer ;