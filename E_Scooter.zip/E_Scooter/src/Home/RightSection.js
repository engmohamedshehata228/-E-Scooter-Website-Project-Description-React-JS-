
import NavBar from './NavBar';
import Decoration from './Decoration';
import Footer from './Footer';
function RightSection()
{
   return(
    <div className="right-section">
       <NavBar/>
       <main className="hero-content fade-in-up">
             <h1 className='zoom-in'>
                    Transform <br/>
                    your mobility <br/>
                    into a fun ride
             </h1>
            <p className="subtitle fade-in-left stagger-1">
                    ENJOY A FUN, CHEAP AND ENVIRONMENTALLY
                    FRIENDLY RIDE WITH <strong>ELECTRIC VEHICLES.</strong>
            </p>
            <button className="btn-order bounce-in stagger-2">ORDER YOURS</button>
             <Footer/>
             <Decoration />
       </main>

    </div>
   );
}

export default RightSection