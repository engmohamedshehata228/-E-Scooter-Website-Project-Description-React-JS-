import NavBar from "../Home/NavBar";
import Decoration from "../Home/Decoration";
import AboutScrollSection from "./AboutScrollSection";
function AboutRightSection()
{
   return(
       <div class="right-section about-layout">
               <NavBar/>
               <AboutScrollSection/>
               <Decoration/>
       </div>
   );
}

export default AboutRightSection ;