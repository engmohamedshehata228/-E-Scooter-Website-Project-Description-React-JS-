
import LeftSection from "../Home/LeftSection";
import AboutRightSection from "./AboutRightSection";
function About()
{
   return(
      <>
     
           <LeftSection pic='scooter.avif' className1="fa-solid fa-arrow-left" c2={"left_in_any_padge"}/>
           <AboutRightSection/>
     
      </>
   );
}

export default About