
function StatsBox({num="1" , htxt="" , ptxt=""})
{
   return(
        <div className={"stat-box bounce-in stagger-"+num} >
            <h2>{htxt}</h2>
            <p>{ptxt}</p>
        </div>
   );
}

export default StatsBox