import Footer from "../Home/Footer";

import AboutTextBlock from "./AboutTextBlock";
import StatsRow from "./StatsRow";
import TeamSection from "./TeamSection";
function AboutScrollSection()
{
   return(
    <div class="scrollable-content">
                <div cla="about-hero fade-in-up">
                    <h1 class="zoom-in">We Move <br/> The <span>Future.</span></h1>
                    <p class="lead fade-in-left stagger-1">Simplifying urban life, one ride at a time.</p>
                </div>
                <AboutTextBlock fadeindiv="right" fadeinp="left"/>
               <StatsRow/>
               <AboutTextBlock fadeindiv="left"  fadeinp="right"/>
               <TeamSection/>
               <Footer/>
    </div>
   );
}

export default AboutScrollSection