import StatsBox from "./StatsBox";

function StatsRow()
{
    return(         
    <div className="stats-row fade-in-up">
                <StatsBox num="1" htxt="50K+" ptxt="Riders" />
                <StatsBox num="2" htxt="60K+" ptxt="Riders" />
                <StatsBox num="3" htxt="20K+" ptxt="Riders" />
                <StatsBox num="2" htxt="15K+" ptxt="Riders" />
                <StatsBox num="1" htxt="2K+" ptxt="Riders" />

          
    </div>
    );
}

export default StatsRow