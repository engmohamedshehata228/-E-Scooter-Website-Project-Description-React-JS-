

function TeamPerson({num , img="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400" , name , posetion})
{

    return(
        <div class="team-grid">
            <div className={"member slide-in-left stagger-"+num}>
                    <div class="avatar"></div>
                    <h4>{name}</h4>
                    <span>{posetion}</span>
            </div>
        </div>
    );
}

export default TeamPerson