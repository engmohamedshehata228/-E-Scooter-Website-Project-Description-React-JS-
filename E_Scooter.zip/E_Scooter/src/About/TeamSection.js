import TeamPerson from "./TeamPerson";

function TeamSection()
{
   return(
    <div class="team-section fade-in-up">
          <h3 class="zoom-in">Meet the Team</h3>
          <TeamPerson num={1} name={"mohamed"} posetion={"CEO"} />
          <TeamPerson num={2} name={"sarah"} img="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400" posetion={"CEO"}/>
          <TeamPerson num={3} name={"mike"} img="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400"  posetion={"CEO"}/>
    </div>
   );
}


export default TeamSection