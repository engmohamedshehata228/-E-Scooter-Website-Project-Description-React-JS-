

function AboutTextBlock({fadeindiv="" , fadeinh3="" , fadeinp=""})
{
   return(
    <div className={"text-block fade-in-"+ fadeindiv}>
        <h3 className={"fade-in-up"}>Who We Are</h3>
        <p className={"fade-in-" + fadeinp +" stagger-1"}>
            E-Scooter isn't just a company; it's a movement towards smarter, cleaner cities.
            Founded in 2021, we noticed that modern transportation was becoming stressful and polluting.
            We decided to change that by engineering the most reliable electric scooters in the market.
        </p>
    </div>
   );
}

export default AboutTextBlock